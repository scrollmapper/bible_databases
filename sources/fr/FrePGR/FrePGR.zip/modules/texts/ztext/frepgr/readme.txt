FrePGR version 1.0 (december 2011)
=====================================================
EN.

This Sword Bible module is composed of the Old Testament, translated from Hebrew to French by Auguste Perret-Gentil (1797-1865), and of the New Testament, translated from Greek to French by Albert Rilliet (1809-1883). These two works were quite innovative in the 19th century because they departed from the Ostervald version, traditional among protestants. Perret-Gentil went back to the original hebrew text (subsequently Louis Segond has borrowed a lot from it), and Rilliet put aside the Textus Receptus for using exclusively the Vaticanus.

For practical reasons the verses reference have been modified to match the KJV one.
=====================================================
FR.

Ce module Sword réunit la traduction de l'Ancien Testament par Auguste Perret-Gentil (1797-1865), et la traduction du Nouveau Testament par Albert Rilliet (1809-1883). Ces deux traductions firent sensation en leur temps, parce qu'elles étaient les premières à s'émanciper de la version Ostervald, traditionnelle chez les protestants. Perret-Gentil traduisit directement d'après l'original hébreu, tout en contrôlant avec la version allemande de De Wette. Plus tard, Louis Segond s'est beaucoup inspiré du travail de Perret-Gentil. Quant à Rilliet, il laissa délibérément le Textus Receptus pour n'utiliser que le Vaticanus (Rilliet donne ses raisons dans sa préface). L'ensemble est écrit dans un beau français ; les quelques mots ou expressions disparues que le lecteur y rencontrera, serviront d'agréable stimulant pour son intelligence, et pour sa volonté de saisir le sens du texte.


Afin de faciliter l'intégration aux logiciels bibliques, la numération des versets est celle de la King James.
=====================================================
Claude Royère 
claude.royere@gmail.com
http://theotex.org
